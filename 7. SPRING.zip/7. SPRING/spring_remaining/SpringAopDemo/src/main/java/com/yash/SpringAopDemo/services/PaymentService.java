package com.yash.SpringAopDemo.services;

public interface PaymentService {

	public void makePayment();

}