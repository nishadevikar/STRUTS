package com.yash.SpringAopDemo.aspect;

import org.aspectj.lang.annotation.After;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {

	@Before("myCustomMethod()")
	public void printBefore() {
		System.out.println("Payment Initilaized");
	}

	@After("myCustomMethod()")
	public void printAfter() {
		System.out.println("Payment Completed");
	}
	
//	@Pointcut("execution(* com.yash.aopimpl.services.PaymentServiceImpl.makePayment())")
//	public void myCustomMethod() {}
	
	@Pointcut("execution(public void *.makePayment())")
	public void myCustomMethod() {}
}