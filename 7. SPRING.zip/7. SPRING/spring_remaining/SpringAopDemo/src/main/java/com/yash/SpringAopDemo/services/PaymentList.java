package com.yash.SpringAopDemo.services;

public class PaymentList implements PaymentService {
	
	public void makePayment() {
		System.out.println("Debit list");
		System.out.println("Credit list");
	}

}
