package com.yash.aopimpl.services;

public class PaymentList implements PaymentService {
	
	public void makePayment() {
		System.out.println("Debit list");
		System.out.println("Credit list");
	}

}
