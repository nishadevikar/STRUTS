package Trainee;
public class hir
{
	 
	public void display()
	{
	String name = "Tanay Pratap Singh";
	 String designation = "Human Resource Executive";
	 String baseunit = "BG5-BU14";
	 String email = "tanay.singh@yash.com";
	 String location = "Indore IT Crystal Park";
		System.out.println("Details Of HR:");
		
		System.out.println("Employee_name = " + name);
	    System.out.println("Employee_Designation = " +designation);
	    System.out.println("BaseUnit = " + baseunit);
        System.out.println("YASH_email = " + email);
	    System.out.println("BaseLocation = " + location);
	}
}
