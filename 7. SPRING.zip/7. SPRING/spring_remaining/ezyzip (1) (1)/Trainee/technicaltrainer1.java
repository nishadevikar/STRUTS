package Trainee;
public class technicaltrainer1
{
	 
	public void display()
	{
	String name = "Jaynam Sanghvi";
	 String designation = "Technical Trainer";
	 String baseunit = "BG5-BU14";
	 String email = "jaynam.sanghvi@yash.com";
	 String location = "Indore Crystal IT Park";
		System.out.println("Details Of Technical Trainer is:");
		
		System.out.println("Employee_name = " + name);
	    System.out.println("Employee_Designation = " +designation);
	    System.out.println("BaseUnit = " + baseunit);
        System.out.println("YASH_email = " + email);
	    System.out.println("BaseLocation = " + location);
	}
	
}
