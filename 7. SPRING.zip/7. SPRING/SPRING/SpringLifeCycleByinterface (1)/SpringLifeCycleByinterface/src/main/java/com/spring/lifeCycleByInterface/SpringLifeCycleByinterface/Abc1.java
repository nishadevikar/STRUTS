package com.spring.lifeCycleByInterface.SpringLifeCycleByinterface;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.Lifecycle;

public class Abc1 implements InitializingBean,DisposableBean {

	
	private String name;
	
	public void setname(String name)
	{
		this.name= name;
	}
	
	public String getName()
	{
		return name;
	}
	
	@Override
	public String toString() {
		return "Abc1 [name=" + name + "]";
	}

	@Override
	public void afterPropertiesSet() throws Exception {
	System.out.println("Abc1 init method call");
		
	}

	@Override
	public void destroy() throws Exception {
		System.out.print("Abc1 destroy method is call");
		
	}

	}

	
