package com.yash.Employeejdbc.entities;

import java.sql.Date;

public class Employee {
	private String empname, emailid;
	private int dob;
	private int contactno;
	private int salary;
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public int getDob() {
		return dob;
	}
	public void setDob(int dob) {
		this.dob = dob;
	}
	public int getContactno() {
		return contactno;
	}
	public void setContactno(int contactno) {
		this.contactno = contactno;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empname=" + empname + ", emailid=" + emailid + ", dob=" + dob + ", contactno=" + contactno
				+ ", salary=" + salary + "]";
	}
	
	
	
}
	