package com.yash.Employeejdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;


import com.yash.Employeejdbc.entities.*;




public class EmployeeDaoImpl implements EmployeeDao{
	private JdbcTemplate jdbctemp;
	public  int insert(Employee emp) {
	
		String q = "insert into employee(empname,emailid,dob,contactno,salary) values(?,?,?,?,?)";
		
		int msg = this.jdbctemp.update(q, emp.getEmpname(), emp.getEmailid(),emp.getDob(),emp.getContactno(),emp.getSalary());
		return msg;
		public JdbcTemplate getJdbctemp() {
			return jdbctemp;
		}

		public void setJdbctemp(JdbcTemplate jdbctemp) {
			this.jdbctemp = jdbctemp;
		}
	}
}
		



