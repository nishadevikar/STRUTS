package com.yash.Employeejdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.Employeejdbc.dao.EmployeeDao;
import com.yash.Employeejdbc.entities.Employee;




/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/Employeejdbc/applicationcontext.xml");
		EmployeeDao emdao = context.getBean("EmployeeDao", EmployeeDao.class);
		
		Employee e = new Employee();
		e.setEmpname("Nisha");
		e.setEmailid("nisha.devikar@yash.com");
		e.setDob(9);
		e.setContactno(750638008);
		e.setSalary(1000);
		int r = emdao.insert(e);//insert
		
		System.out.println(r + "Employee added Successfully ");
		
		
    }
}
