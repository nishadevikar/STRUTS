package com.property.message;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/property/message/Beans.xml");
		//System.out.println(context.getMessage("message", args, "Default message", null));
		System.out.println(context.getMessage("message1", args, null));
		//((AbstractApplicationContext) context).close();
		
		
		//System.out.println(context.getMessage("message", args, null));
	}

}
