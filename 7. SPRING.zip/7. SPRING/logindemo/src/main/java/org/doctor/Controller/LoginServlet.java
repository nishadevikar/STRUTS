package org.doctor.Controller;


import java.io.IOException;
import java.io.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
 private static final long serialVersionUID = 1L;

 /**
  * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
  *      response)
  */
 protected void doPost(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {
  response.setContentType("text/html");
  PrintWriter out = response.getWriter();
  // ServletContext sc = getServletContext();
  HttpSession session = request.getSession();
  String email = request.getParameter("email");

  session.setAttribute("email", email);
  // String email1=sc.getInitParameter("email");
  // sc.setAttribute("email",email);
  String password = request.getParameter("password");
  // HttpSession session=request.getSession();

  try {
   Class.forName("com.mysql.jdbc.Driver");
   Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/doctordb", "root", "root");
   PreparedStatement pst = conn
     .prepareStatement("Select email,password from login where email=? and password=?");
   pst.setString(1, email);
   pst.setString(2, password);
   ResultSet rs = pst.executeQuery();
   if (rs.next()) {
    out.print("You are successfully loggedin...");
    request.getRequestDispatcher("Welcome").include(request, response);
   } else {

    out.println("Username or Password incorrect");
    request.getRequestDispatcher("Login.html").include(request, response);

   }
  } catch (ClassNotFoundException | SQLException e) {
   e.printStackTrace();
  }
 }
}