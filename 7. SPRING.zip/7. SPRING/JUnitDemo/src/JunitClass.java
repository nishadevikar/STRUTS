import org.junit.Test;

public class JunitClass {
	
	@Test
	public void JunitMethod() {
		System.out.print("Executing Junit Test Cases");
	}
	public static void main(String[] args) {
		

	}

}
