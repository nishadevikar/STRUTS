
public class M {
	public void mAdd() 
    {
        System.out.println("And I Have Add data");
    }
}
