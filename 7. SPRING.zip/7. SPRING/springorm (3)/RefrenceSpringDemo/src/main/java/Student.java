
public class Student {
	private int id;
    private M m;
    public void add() 
    {

        System.out.println("My ID is: " + id);

        m.mAdd();
    }

    public Student(int id, M m)
    {
        this.id = id;
        this.m = m;
    }
}
