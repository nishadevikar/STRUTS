package com.yash.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.EmployeeDao;
import com.yash.springjdbc.entities.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		EmployeeDao stdao = context.getBean("StudentDao", EmployeeDao.class);

		Employee s = new Employee();
		s.setEmpname("Nisha Devikar");
		s.setEmpid(111);
		s.setDob("9th Nov 1999");
		s.setContactno("7506380087");
		s.setSalary(10000);

		int r = stdao.insert(s);//insert the details
		System.out.println(r + "Emloyee details inserted successfully");
		//int r=stdao.updatedetails(s);//update the details
		//System.out.println(r + "Student added Successfully ");
		//System.out.println(r+"Student detail updated");
//		int r=stdao.deletedetails(111);//delete the details
		
	}
}