package com.spring.getmessage.SprinGetMessageProperty;

public class A {

}
