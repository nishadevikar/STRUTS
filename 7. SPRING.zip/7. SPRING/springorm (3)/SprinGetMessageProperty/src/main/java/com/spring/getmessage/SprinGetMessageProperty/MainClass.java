package com.spring.getmessage.SprinGetMessageProperty;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.MessageSourceResourceBundle;

public class MainClass {

	public static void main(String[] args) {
		
		MessageSource c = new ClassPathXmlApplicationContext("getmessagecfg.xml");

		System.out.println(c.getMessage("one",null,"default argument",null));
	}
}
