import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

//Application class 


//Main class
public class DemoApplication {

// Main driver method
public static void main(String[] args) {

 // Creating object in a spring container (Beans)
 BeanFactory factory = new ClassPathXmlApplicationContext("bean-factorydemo.xml");
 Student student = (Student) factory.getBean("student");

 System.out.println(student);
}
}