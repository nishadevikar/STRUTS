
public class B {
	B() //constructor of B
	{
		System.out.println("b is created");
		
	}  
	void print()   //print method
	{
		System.out.println("hello b");
		
	}  

}
